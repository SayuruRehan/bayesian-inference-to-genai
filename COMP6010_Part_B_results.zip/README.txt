COMP6010 Part B reproduction

Run COMP6010_Part_B_Guided_Colab.ipynb in order with Python 3, NumPy, pandas, Matplotlib and SciPy.
No external dataset, API key, GPU or trained weights are required. Computation normally takes seconds;
notebook startup, reading and rendering add overhead. Actual package versions are recorded.

input_batches.csv: new observations per batch.
posterior_updates.csv: cumulative data, posterior shapes and point estimates.
uncertainty_and_decision.csv: predictive probability, interval, tail area and rule decision.
monte_carlo_verification.csv and posterior_draws.npy: sampling verification and full parameter draws.
prior_sensitivity.csv: three priors at the two required stages.
numerical_checks.json: independent integration checks.
PNG/PDF figures: graph, prior/posteriors and final threshold area.
configuration.json and requirements_observed.txt: settings, seed and runtime versions.
ai_use_log_template.md: complete with your actual personal checks and decisions.

Save the executed notebook separately and include it alongside this evidence in the final supplement.
This export covers Part B only, not the complete assignment.
Source of all observations: COMP6010_Assignment_2026.docx.
