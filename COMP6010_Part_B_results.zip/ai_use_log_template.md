# Part B AI-use record to complete

- Date: [enter actual date].
- Tool/model: ChatGPT; record the visible model label if available.
- Prompt: 'check this colab run output and continue'
- Assistance: Part A output review; guided Part B code, mathematical explanation and verification.
- Relevant response excerpt: 'I’ll check your Part A outputs and any unfinished sections, then prepare the guided Part B notebook.'
- Assistant checks: sequential/pooled agreement, independent kernel integration and posterior simulation.
- My independent check: [personally verify a batch update, source, integral or output].
- My evidence/source: [complete].
- My decision or change: [complete].

## Prediction versus observation
- Prediction before a NEW experiment, with date: [complete].
- Whether I had already viewed saved outputs: [state honestly].
- Setting or Monte Carlo seed: [complete].
- Observation and supporting output: [complete].
- Decision or explanation: [complete].

Keep 3–5 selected interactions across Parts A, B and C. Do not claim assistant checks as your own
or invent an earlier prediction. This is a template, not a completed declaration.
