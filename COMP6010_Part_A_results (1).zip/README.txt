COMP6010 Part A results

Run the guided notebook from top to bottom in Python 3 with numpy, pandas and matplotlib.
No dataset, GPU, checkpoint or API access is needed for this part.
requirements_observed.txt records the versions actually used for this export.
configuration.json records CPTs, stream keys, hardware information and measured inference time.
Inference takes seconds on an ordinary CPU; notebook startup and figure rendering add overhead.
Measured wall-clock time depends on the machine and current load.

Files:
- exact_joint_32_states.csv and exact_queries.csv: correctness references.
- per_run_results.csv: all 90 estimates, diagnostics and exact-reference errors.
- summary.csv: means, sample standard deviations and mean absolute errors.
- per_run_timings.csv and timing_summary.csv: all-three-query cost with shared sampling counted once.
- network.png and q2_convergence.png/pdf: report figures.
- ai_use_log_template.md: complete with your actual verification and decisions.

Save the notebook WITH OUTPUTS separately and include it beside these files in the final supplement.
This export contains Part A only; it is not the complete assignment supplement.
Source model: COMP6010_Assignment_2026.docx. No external datasets or private information are included.
