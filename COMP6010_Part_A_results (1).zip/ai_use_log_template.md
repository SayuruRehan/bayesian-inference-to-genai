# AI-use log to complete

## Interaction 1
- Date: 12 September 2026 (confirm your session date).
- Tool/model: ChatGPT; add the exact model label if visible.
- User prompt: 'ill be running in colab lets start'
- Assistance received: guided Part A notebook, explanations, sampling implementation and assistant-side checks.
- Relevant response excerpt: 'I’ll start with a Colab notebook for Part A, with explanations, both samplers, and checks against the exact answers.'
- Assistant verification: numerical comparison with an independent rational-arithmetic reference; deterministic estimator checks; complete experiment execution.
- My independent check: [complete after personally checking a CPT, calculation, source or output].
- Evidence or source used for my check: [complete].
- My resulting decision or code change: [complete].

## Prediction versus observation
- Prediction and reason, recorded before a new run: [complete].
- Had I already seen earlier saved outputs? [state honestly].
- Setting/seed to test: [complete].
- Observed result and evidence file: [complete].
- Decision or revision: [complete].

Add selected interactions for Parts B and C to reach 3–5 across the assignment.
