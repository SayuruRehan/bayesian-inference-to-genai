COMP6010 C2 fresh 64-seed follow-up evaluation.
Read export_status.json first. Original experiments remain unchanged.
protocol.json: pre-generation follow-up predictions, seeds and rubric.
generation_complete.json: device/versions/checkpoint-linked protocol and array hashes.
human_ratings.csv: actual rater entries; configuration key joins IDs to configs/seeds.
quality_summary.csv: Wilson intervals conditional on model/rater.
paired_comparisons.csv: 20000 seed-paired percentile bootstrap resamples; not an equivalence test.
timing_repeats.csv: five rounds, batch16, all64 images per timed evaluation.
blinded_grids and labelled_grids: full image sets; arrays remain unclipped.
Checkpoints are referenced by hashes; original checkpoint ZIP is still required for reproduction.
Student must save the executed notebook separately. No new training was performed.
