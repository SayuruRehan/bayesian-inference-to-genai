COMP6010 C2 final review of post-feedback reassessment.
Read export_status.json first. CPU only; no new generation or training.
input_reassessment_results.zip preserves the incoming reassessment; history_before_corrections retains its earlier reflection.
Corrected reflection is AI-assisted and saved only after student review and count confirmation.
source_snapshot/original_scored_results.zip is the unchanged original upload.
second_pass_ratings.csv holds real user-entered reassessment ratings; original scores are preserved.
both_passes_quality_summary.csv and both_passes_paired_comparisons.csv retain both results.
rating_change_audit.csv and agreement_matrix.csv describe within-rater changes, not accuracy.
Reassessment follows AI feedback and prior results; it does not restore original blinding.
Real calibration images: Google Quick, Draw! dataset, CC BY 4.0; https://github.com/googlecreativelab/quickdraw-dataset
Calibration provenance includes source rows/hashes, original split hash and deterministic sampling seed.
Intervals condition on one rater and trained checkpoints; subjective threshold uncertainty is not represented.
Original timings are reused and explicitly labelled. Save the executed notebook separately.
